package distributed.transaction.utils;


/**
 * 事件类型
 *
 * @author Dean
 */
public enum EventType {
	/**
	 * 用户创建成功
	 */
	USER_CREATED
}
